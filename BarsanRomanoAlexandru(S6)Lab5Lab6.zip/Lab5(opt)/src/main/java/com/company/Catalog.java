package com.company;

import java.io.Serializable;
import java.util.*;

public class Catalog implements Serializable {
    private List<Document> documents = new ArrayList<>();
    private String name;
    private String path;


    public Catalog() {
    }

    public Catalog(String name, String path) {
        this.name = name;
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public List<Document> getDocuments() {
        return documents;
    }


    public void add(Document doc) {
        documents.add(doc);
    }
    public Document findById(String id) {
        return documents.stream()
                .filter(d -> d.getId().equals(id)).findFirst().orElse(null);
    }

    public String getPath() {
        return path;
    }

    @Override
    public String toString() {
        return "{" +
                "\n  name:'" + name + '\'' +
                ",\n  path:'" + path + '\'' +
                ",\n  documents:" + documents +
                "\n}";
    }
}
