package com.company;


import java.io.*;

public class Main {
        static Catalog  catalog = null;
        public static void main(String[] args) throws
        java.io.IOException {

            String commandLine;
            BufferedReader console = new BufferedReader(new InputStreamReader(System.in));

            while (true) {
                //read the command
                System.out.print("shell>");
                commandLine = console.readLine();

                //if just a return, loop
                if (commandLine.equals("")){
                    continue;
                }

                //clear screen
                if (commandLine.equals("clear")) {
                    for (int cls = 0; cls < 100; cls++ ){
                        System.out.println("");
                    }
                    continue;
                }
                if (commandLine.equals("exit")) {
                    System.out.println("Exiting");
                    System.exit(0);

                }

                //help command
                if (commandLine.equals("help")) {
                    System.out.println("Use: ");
                    System.out.println("load {path}");
                    System.out.println("list {id}");
                    System.out.println("view");
                    System.out.println("clear");
                    System.out.println("help");
                }

                //if it actually receives a command
                if(commandLine.startsWith("load ")) {
                    String[] argumente = commandLine.split(" ");
                    if (argumente.length != 2){
                        System.out.println("Write \"help\" for help");
                        continue;
                    }
                    LoadCommand x = new LoadCommand(catalog, argumente[1]);
                    x.executeSelf();
                    catalog = x.getCatalog();
                    continue;
                }

                if (commandLine.equals("view")) {
                    if(catalog != null && catalog.getPath() !=null){
                        new ViewCommand(catalog.getPath()).executeSelf();
                    } else {
                        System.out.println("You have to load catalog first");
                    }
                    continue;
                }


                if (commandLine.startsWith("list")) {
                    if(catalog == null){
                        System.out.println("you have to load catalog first");
                        continue;
                    }
                    String[] argumente = commandLine.split(" ");
                    if (argumente.length != 2){
                        System.out.println("Write \"help\" for help");
                    }
                    new ListCommand(catalog, argumente[1]).executeSelf();
                }
                //in case everything fails, goes to help
                System.out.println("Write \"help\" for help");
            }
        }
    }
