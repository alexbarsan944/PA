import java.sql.*;


public class Main {

    public static void main(String[] args) {
        Connection conn = null;
        Statement st = null;
        try{
            Database baza = Database.getInstance();
            conn = baza.getConnection();
            System.out.println("Connected");

            st = conn.createStatement();

            String sql = "CREATE DATABASE  MusicAlbums";

           /**
            Se creeaza  baza de date MusicAlbums
            st.executeUpdate(sql);
            */

            String create_user = "grant all privileges on mydb.* to 'dba'@'localhost' identified by 'sql';";
            st.executeUpdate(create_user); /**  Cream userul dba cu parola sql **/


            System.out.println("User created successfully");


            String artists = "create table artists(" +
                    "    id integer not null auto_increment," +
                    "    name varchar(100) not null," +
                    "    country varchar(100)," +
                    "    primary key (id)" +
                    ");";

            String albums = "create table albums(" +
                    "id integer not null auto_increment," +
                    "name varchar(100) not null," +
                    "artist_id integer not null references artists on delete restrict," +
                    "release_year integer," +
                    "primary key (id)" +
                    ");";

            st.executeUpdate("DROP TABLE artists;");
            st.executeUpdate(artists);
            System.out.println("Artists table created successfully");
            st.executeUpdate("DROP TABLE albums;");
            st.executeUpdate(albums);
            System.out.println("Albums table created successfully");

            ArtistController.create("Radiohead", "UK");
            ArtistController.create("Pink Floyd", "UK");
            ArtistController.findByName("Radiohead");

            AlbumController.create("OK Computer", 1, 1997);
            AlbumController.create("Wish You Were Here", 2, 1975);

            AlbumController.findByArtist(2);

        }catch(SQLException se){
            se.printStackTrace();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            try{
                if(st!=null)
                    st.close();
            }catch(SQLException se2){
            }
            try{
                if(conn!=null)
                    conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
    }
}