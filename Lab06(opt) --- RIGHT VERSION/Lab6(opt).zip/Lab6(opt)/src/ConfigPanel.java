import javax.swing.*;
import java.awt.*;
import java.lang.reflect.Field;

public class ConfigPanel extends JPanel {

    public static Color stringToColor(final String value) {
        if (value == null) {
            return Color.black;
        }
        try {
            // get color by hex or octal value
            return Color.decode(value);
        } catch (NumberFormatException nfe) {
            // if we can't decode lets try to get it by name
            try {
                // try to get a color by name using reflection
                final Field f = Color.class.getField(value);

                return (Color) f.get(null);
            } catch (Exception ce) {
                // if we can't get any color return black
                return Color.black;
            }
        }
    }


    final MainFrame frame;
    JLabel label; // we’re drawing regular polygons
    JSpinner sidesField; // number of sides
    JSpinner shapesField;
    JComboBox colorCombo; // the color of the shape
    JComboBox shapesCombo, retained, delete;


    public ConfigPanel(MainFrame frame) {
        this.frame = frame;
        init();
    }
    private void init() {
        //create the label and the spinner
        String s[] = new String[]{"Random", "Black"};
        String shapes[] = new String[]{"Patrat", "Triunghi"};
        String retain[] = new String[]{"Retained", "Direct"};
        String draw[] = new String[]{"Draw", "Delete"};
        JLabel sidesLabel = new JLabel("Number of sides:");
        sidesField = new JSpinner(new SpinnerNumberModel(0, 0, 100, 1));
        sidesField.setValue(4); //default number of sides

        colorCombo = new JComboBox(s);
        colorCombo.setBounds(50, 50,90,20);

        shapesCombo = new JComboBox(shapes);
        shapesCombo.setBounds(50,50,90,20);

        retained = new JComboBox(retain);
        retained.setBounds(50,50,90,20);

        delete = new JComboBox(draw);
        delete.setBounds(50,50,90,20);


        //create the colorCombo, containing the values: Random and Black
        //TODO
        add(sidesLabel); //JPanel uses FlowLayout by default
        add(sidesField);
        add(colorCombo);
        add(shapesCombo);
        add(retained);
        add(delete);
    }
}
