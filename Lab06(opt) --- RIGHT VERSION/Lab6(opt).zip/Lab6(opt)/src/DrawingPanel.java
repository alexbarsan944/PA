import javafx.util.Pair;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DrawingPanel extends JPanel {
    final MainFrame frame;
    final static int W = 800, H = 600;
    BufferedImage image; //the offscreen image
    Graphics2D graphics; //the "tools" needed to draw in the image
    List<Pair<Color,Shape>> pairList = new ArrayList<>();
    List<Shape> shapeList = new ArrayList<>();

    public DrawingPanel(MainFrame frame) {
        this.frame = frame; createOffscreenImage(); init();
    }
    private void createOffscreenImage() {
        image = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        graphics = image.createGraphics();
        graphics.setColor(Color.WHITE); //fill the image with white
        graphics.fillRect(0, 0, W, H);
    }
    private void init() {
        setPreferredSize(new Dimension(W, H)); //don’t use setSize. Why?
        setBorder(BorderFactory.createEtchedBorder()); //for fun
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if(frame.configPanel.delete.getSelectedItem().toString().equals("Draw")) {
                    drawShape(e.getX(), e.getY());
                    repaint();
                }
                else
                if(frame.configPanel.delete.getSelectedItem().toString().equals("Delete"))
                {
                    deleteShape(e.getX(),e.getY());
                    repaint();
                }

            } //Can’t use lambdas, JavaFX does a better job in these cases
        });
    }
    public void drawRetained(){
        for (Pair<Color, Shape> p : frame.canvas.pairList) {
            frame.canvas.graphics.setColor(p.getKey());
            frame.canvas.graphics.fill(p.getValue());
        }
    }
    public void deleteShape(int x, int y) {
        for (Shape s : shapeList) {
            if (s.contains(x, y) == true) {
                graphics.setColor(Color.white);
                graphics.fill(s);
            }
        }
    }

    private void drawShape(int x, int y) {
        Random rand = new Random();
        int r = rand.nextInt(128) + 128;
        int g = rand.nextInt(128) + 128;
        int b = rand.nextInt(128) + 128;


        int radius = rand.nextInt(100);
        int sides = (Integer)frame.configPanel.sidesField.getValue();
        String culoare = frame.configPanel.colorCombo.getSelectedItem().toString();
        Color color;
        if(culoare.equals("Random")) {
            color = new Color(r, g, b);
        }
        else
        {
            color = new Color(0,0,0);
        }

        String forma = frame.configPanel.shapesCombo.getSelectedItem().toString();

        if(forma.equals("Triunghi"))
        {
            frame.configPanel.sidesField.setValue(3);

        }
        else if (forma.equals("Patrat"))
        {
            frame.configPanel.sidesField.setValue(4);
        }

        graphics.setColor(color);
        String where = frame.configPanel.retained.getSelectedItem().toString();
        if(where.equals("Retained"))
        {
            Shape shape = new RegularPolygon(x,y,radius,sides);
            pairList.add(new Pair(color, shape));
            shapeList.add(shape);
        }
        else if(where.equals("Direct"))
        {
            Shape shape = new RegularPolygon(x,y,radius,sides);
            graphics.fill(shape);
            shapeList.add(shape);
        }
    }
    @Override
    public void update(Graphics g) { } //Why did I do that?

    @Override
    protected void paintComponent(Graphics g) {
        g.drawImage(image, 0, 0, this);
    }
}
