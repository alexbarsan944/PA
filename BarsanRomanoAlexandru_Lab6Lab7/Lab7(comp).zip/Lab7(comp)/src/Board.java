import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Board {
    List<Token> tokens = new ArrayList<>();
    private int tokenCount = tokens.size();

    public Board(int tokenCount) {
        this.tokenCount = tokenCount;
        for (int i = 0; i < tokenCount; i++) {
            tokens.add( new Token(i));
        }
    }

    @Override
    public String toString() {
        return "Board{" +
                "tokens=" + tokens +
                '}';
    }

    public synchronized Token pickToken(){
        int bound = tokens.size() -1;
        if(bound <= 0)
            return null;
        int pick = new Random().nextInt(bound);
        Token t = tokens.get(pick);
        tokens.remove(t);
        return t;
    }


    public List<Token> getTokens() {
        return tokens;
    }

    public Token getLastToken(){
        return tokens.get(tokens.size()-1);
    }

    public void setTokens(List<Token> tokens) {
        this.tokens = tokens;
    }

    public void delete()
    {
        tokens.remove(0);
    }
}
