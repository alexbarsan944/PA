public class Token {
    private int number;

    public Token() {

    }

    @Override
    public String toString() {
        return "Token{" +
                "number=" + number +
                '}';
    }

    public Token(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
