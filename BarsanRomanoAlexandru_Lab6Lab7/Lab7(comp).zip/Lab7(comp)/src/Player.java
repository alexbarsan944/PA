import java.util.ArrayList;
import java.util.List;

public class Player implements Runnable {

    private Board board;
    String name;
    int size;
    int tokenCount;
    List<Token> tokens = new ArrayList<>();
    boolean running;
    public Player(String name,int size, int tokenCount, Board board) {
        this.board = board;
        this.name = name;
        this.size = size;
        this.tokenCount = tokenCount;
        Thread t1 = new Thread(this);
        t1.start();
    }


    @Override
    public void run() {
        Token t;
        do{
            t = board.pickToken();
            addToken(t);
        }while (t!=null);
        System.out.println(this);
    }

    public void addToken(Token t){
        this.tokens.add(t);
    }
    public void setRunning(boolean b) {
        running = b;
    }

    @Override
    public String toString() {
        return "Player{" +
                "name='" + name + '\'' +
                ", tokens=" + tokens +
                '}';
    }

    public boolean isRunning() {
        return running;
    }

    public int getSize() {
        return size;
    }


}
