import java.util.ArrayList;
import java.util.List;

public class Main  {
    Player[] players;
    int numberOfPlayers;
    int count;
    int size;
    Board board;

    public Main(int numberOfPlayers, int count, int size) {
        this.numberOfPlayers = numberOfPlayers;
        this.count = count;
        this.size = size;
        board = new Board(count);
        startGame();
    }

    public void startGame(){
        players = new Player[numberOfPlayers];
        for (int i = 0; i < numberOfPlayers; i++) {
            players[i] = new Player("Player " + i, size, count, board);
        }
        while(!winnerExists()) {
        }

        for (int i = 0; i < numberOfPlayers; i++) {
            players[i].setRunning(false);
        }
    }

    private boolean winnerExists() {
        for (int i = 0; i < numberOfPlayers; i++) {
            if(!players[i].isRunning()){
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        new Main(5,30,5);
    }

}
